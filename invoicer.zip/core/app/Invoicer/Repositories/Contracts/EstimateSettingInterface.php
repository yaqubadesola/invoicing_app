<?php namespace App\Invoicer\Repositories\Contracts;


interface  EstimateSettingInterface  extends BaseInterface  {

} 