<?php namespace App\Invoicer\Repositories\Contracts;


interface  PaymentMethodInterface  extends BaseInterface  {

} 