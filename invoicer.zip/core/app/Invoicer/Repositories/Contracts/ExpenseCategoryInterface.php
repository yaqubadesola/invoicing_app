<?php namespace App\Invoicer\Repositories\Contracts;

interface  ExpenseCategoryInterface  extends BaseInterface  {

} 