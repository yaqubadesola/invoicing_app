<?php namespace App\Invoicer\Repositories\Contracts;


interface  TemplateInterface  extends BaseInterface  {

} 