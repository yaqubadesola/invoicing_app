<?php namespace App\Invoicer\Repositories\Contracts;


interface  InvoiceSettingInterface  extends BaseInterface  {

} 