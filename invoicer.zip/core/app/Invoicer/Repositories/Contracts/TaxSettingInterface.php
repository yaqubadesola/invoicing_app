<?php namespace App\Invoicer\Repositories\Contracts;


interface  TaxSettingInterface  extends BaseInterface  {

} 