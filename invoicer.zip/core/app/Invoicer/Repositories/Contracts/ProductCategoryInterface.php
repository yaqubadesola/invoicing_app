<?php namespace App\Invoicer\Repositories\Contracts;

interface  ProductCategoryInterface  extends BaseInterface  {

} 