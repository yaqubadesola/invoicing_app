<?php namespace App\Invoicer\Repositories\Contracts;


interface  NumberSettingInterface  extends BaseInterface  {

} 