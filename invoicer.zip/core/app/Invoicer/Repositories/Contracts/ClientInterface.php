<?php namespace App\Invoicer\Repositories\Contracts;


interface  ClientInterface   extends BaseInterface  {

} 