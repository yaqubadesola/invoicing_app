<?php namespace App\Invoicer\Repositories\Contracts;


interface  ExpenseInterface  extends BaseInterface  {

} 