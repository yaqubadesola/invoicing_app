<?php namespace App\Invoicer\Repositories\Contracts;


interface  CurrencyInterface  extends BaseInterface  {

} 