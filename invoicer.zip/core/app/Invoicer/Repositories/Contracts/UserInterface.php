<?php namespace App\Invoicer\Repositories\Contracts;


interface  UserInterface  extends BaseInterface  {

} 