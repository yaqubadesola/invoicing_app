<?php namespace App\Invoicer\Repositories\Contracts;


interface  EstimateItemInterface  extends BaseInterface  {

} 