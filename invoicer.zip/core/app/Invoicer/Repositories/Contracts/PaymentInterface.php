<?php namespace App\Invoicer\Repositories\Contracts;


interface  PaymentInterface  extends BaseInterface  {}