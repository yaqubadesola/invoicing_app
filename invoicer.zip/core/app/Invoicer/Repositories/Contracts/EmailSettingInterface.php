<?php namespace App\Invoicer\Repositories\Contracts;


interface  EmailSettingInterface  extends BaseInterface  {

} 