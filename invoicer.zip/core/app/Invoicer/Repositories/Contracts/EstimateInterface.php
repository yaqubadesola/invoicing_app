<?php namespace App\Invoicer\Repositories\Contracts;


interface  EstimateInterface  extends BaseInterface  {}