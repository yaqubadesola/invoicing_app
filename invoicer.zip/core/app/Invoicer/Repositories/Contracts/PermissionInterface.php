<?php namespace App\Invoicer\Repositories\Contracts;


interface  PermissionInterface  extends BaseInterface  {

} 