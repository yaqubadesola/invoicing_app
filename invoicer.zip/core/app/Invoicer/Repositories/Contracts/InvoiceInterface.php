<?php namespace App\Invoicer\Repositories\Contracts;


interface  InvoiceInterface  extends BaseInterface  {}