<?php namespace App\Invoicer\Repositories\Contracts;


interface  SettingInterface  extends BaseInterface  {

} 