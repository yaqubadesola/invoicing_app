<?php namespace App\Invoicer\Repositories\Contracts;


interface  RoleInterface  extends BaseInterface  {

} 