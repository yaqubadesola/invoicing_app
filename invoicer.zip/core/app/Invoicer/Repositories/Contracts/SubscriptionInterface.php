<?php namespace App\Invoicer\Repositories\Contracts;


interface  SubscriptionInterface  extends BaseInterface  {

} 