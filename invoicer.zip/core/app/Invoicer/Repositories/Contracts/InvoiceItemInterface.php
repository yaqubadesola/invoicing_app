<?php namespace App\Invoicer\Repositories\Contracts;


interface  InvoiceItemInterface  extends BaseInterface  {

} 