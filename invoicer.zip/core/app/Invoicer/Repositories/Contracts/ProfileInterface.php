<?php namespace App\Invoicer\Repositories\Contracts;


interface  ProfileInterface  extends BaseInterface  {

} 