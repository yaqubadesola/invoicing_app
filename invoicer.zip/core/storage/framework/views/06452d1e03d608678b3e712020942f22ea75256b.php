<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('name', trans('application.name')); ?>

            <?php echo Form::text('name', null, ['class' => "form-control input-sm required", 'required']); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\invoicer\core\resources\views/expenses/categories/_form.blade.php ENDPATH**/ ?>