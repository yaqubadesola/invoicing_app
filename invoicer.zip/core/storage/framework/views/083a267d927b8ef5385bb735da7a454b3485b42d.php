
<?php $__env->startSection('content'); ?>

    <div class="col-md-12 content-header" >
        <h1><i class="fa fa-dashboard"></i> <?php echo e(trans('application.dashboard')); ?></h1>
    </div>
    <section class="content">
        <?php if(!empty($user) && $user->role['name'] == "admin"): ?>
        <div class="row">
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <i class="fa fa-users bg-aqua"></i>
                    <span class="info-box-text"><?php echo e(trans('application.clients')); ?></span>
                    <span class="info-box-number"><?php echo e($clients); ?></span>
                </div><!-- /.info-box -->
            </div><!-- /.col -->
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <i class="fa fa-file-pdf-o bg-green"></i>
                    <span class="info-box-text"><?php echo e(trans('application.invoices')); ?></span>
                    <span class="info-box-number"><?php echo e($invoices); ?></span>
                </div><!-- /.info-box -->
            </div><!-- /.col -->
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <i class="fa fa-list-alt bg-yellow"></i>
                    <span class="info-box-text"><?php echo e(trans('application.estimates')); ?></span>
                    <span class="info-box-number"><?php echo e($estimates); ?></span>
                </div><!-- /.info-box -->
            </div><!-- /.col -->
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <i class="fa fa-puzzle-piece bg-red"></i>
                    <span class="info-box-text"><?php echo e(trans('application.products')); ?></span>
                    <span class="info-box-number"><?php echo e($products); ?></span>
                </div><!-- /.info-box -->
            </div><!-- /.col -->
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="panel panel-primary dashboard_stats">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-ngn fa-3x">&#8358;</i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <p class="info-box-number"><?php echo e($invoice_stats['partiallyPaid']); ?></p>
                                <p class="info-box-text"><?php echo e(trans('application.invoices_partially_paid')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="panel bg-yellow dashboard_stats">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-money fa-3x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <p class="info-box-number"><?php echo e($invoice_stats['unpaid']); ?></p>
                                <p class="info-box-text"><?php echo e(trans('application.unpaid_invoices')); ?></p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="panel bg-red dashboard_stats">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-times fa-3x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <p class="info-box-number"><?php echo e($invoice_stats['overdue']); ?></p>
                                <p class="info-box-text"><?php echo e(trans('application.invoices_overdue')); ?> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="panel bg-green dashboard_stats">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-check fa-3x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <p class="info-box-number"><?php echo e($invoice_stats['paid']); ?></p>
                                <p class="info-box-text"><?php echo e(trans('application.paid_invoices')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 text-center">
                <div class="box box-primary">
                    <div class="box-body">
                        <div id="yearly_overview">
                            <h4><?php echo e(trans('application.yearly_overview')); ?></h4>
                            <canvas id="yearly_overview_inner"></canvas>
                        </div><!-- /.col -->
                    </div><!-- ./box-body -->
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="box box-primary">
                    <div class="box-body">
                        <div id="payment_overview">
                            <h4><?php echo e(trans('application.payment_overview')); ?></h4>
                            <canvas id="payment_overview_inner"></canvas>
                        </div><!--/.col -->
                    </div><!-- ./box-body -->
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo e(trans('application.recent_invoices')); ?></h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('application.invoice_number')); ?></th>
                                <th><?php echo e(trans('application.invoice_status')); ?></th>
                                <th><?php echo e(trans('application.client')); ?></th>
                                <th><?php echo e(trans('application.date')); ?></th>
                                <th><?php echo e(trans('application.due_date')); ?></th>
                                <th><?php echo e(trans('application.amount')); ?></th>
                                <th width="20%"><?php echo e(trans('application.action')); ?> </th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $x = 1; ?>
                            <?php $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count=>$invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->role['name'] != "admin" && $user['uuid'] != $invoice->user_id): ?>
                                <?php continue; ?>
                                <?php endif; ?>
                                <tr><?php 
                                        $client_rec = \App\Models\Client::where("uuid",$invoice->client_id)->get();
                                    ?>
                                    <td><?php echo e($x++); ?>

                                    </td>
                                    <td><a href="<?php echo e(route('invoices.show', $invoice->uuid)); ?>"><?php echo e($invoice->number); ?></a> </td>
                                    <td><span class="label <?php echo e(statuses()[$invoice->status]['class']); ?>"><?php echo e(ucwords(statuses()[$invoice->status]['label'])); ?> </span></td>
                                    <td><a href="<?php echo e(route('clients.show', $invoice->client_id)); ?>"><?php echo e($client_rec[0]['name'] ?? ''); ?></a> </td>
                                    <td><?php echo e($invoice->invoice_date); ?> </td>
                                    <td><?php echo e($invoice->due_date); ?> </td>
                                    <td><?php echo '<span style="display:inline-block">'.$invoice->currency.'</span><span style="display:inline-block"> '.format_amount($invoice->totals['grandTotal']).'</span>'; ?> </td>
                                    <td>
                                        <a href="<?php echo e(route('invoices.show',$invoice->uuid)); ?>" class="btn btn-xs btn-info"><i class="fa fa-eye"></i> <?php echo e(trans('application.view')); ?> </a>
                                        <?php if(hasPermission('edit_invoice')): ?>
                                            <a href="<?php echo e(route('invoices.edit',$invoice->uuid)); ?>" class="btn btn-xs btn-success"><i class="fa fa-pencil"></i> <?php echo e(trans('application.edit')); ?> </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo e(trans('application.recent_estimates')); ?></h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('application.estimate_number')); ?></th>
                                <th><?php echo e(trans('application.client')); ?></th>
                                <th><?php echo e(trans('application.date')); ?></th>
                                <th><?php echo e(trans('application.amount')); ?></th>
                                <th width="20%"><?php echo e(trans('application.action')); ?> </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $y = 1; ?>
                            <?php $__currentLoopData = $recentEstimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count=>$estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($user->role['name'] != "admin" && $user['uuid'] != $invoice->user_id): ?>
                                <?php continue; ?>
                                <?php endif; ?>
                                <tr>
                                    <?php 
                                        $client_rec = \App\Models\Client::where("uuid",$estimate->client_id)->get();
                                    ?>
                                    <td><?php echo e($y++); ?></td>
                                    <td><a href="<?php echo e(route('estimates.show', $estimate->uuid)); ?>"><?php echo e($estimate->estimate_no); ?> </a></td>
                                    <td><a href="<?php echo e(route('clients.show', $estimate->client_id)); ?>"><?php echo e($client_rec[0]['name'] ?? ''); ?></a> </td>
                                    <td><?php echo e($estimate->estimate_date); ?> </td>
                                    <td><?php echo '<span style="display:inline-block">'.$estimate->currency.'</span><span style="display:inline-block"> '.format_amount($estimate->totals['grandTotal']).'</span>'; ?> </td>
                                    <td>
                                        <a href="<?php echo e(route('estimates.show',$estimate->uuid)); ?>" class="btn btn-xs btn-info"><i class="fa fa-eye"></i> <?php echo e(trans('application.view')); ?> </a>
                                        <?php if(hasPermission('edit_estimate')): ?>
                                            <a href="<?php echo e(route('estimates.edit',$estimate->uuid)); ?>" class="btn btn-xs btn-success"><i class="fa fa-pencil"></i> <?php echo e(trans('application.edit')); ?> </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>

    <script>
        var income_data     = JSON.parse('<?php echo $yearly_income; ?>');
        var expense_data    = JSON.parse('<?php echo $yearly_expense; ?>');
        var lineChartData   = {
            labels : ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
            datasets : [{
                label               : "<?php echo e(trans('application.income')); ?>",
                fillColor           : "rgba(14,172,147,0.1)",
                strokeColor         : "rgba(14,172,147,1)",
                pointColor          : "rgba(14,172,147,1)",
                pointStrokeColor    : "#fff",
                pointHighlightFill  : "rgba(54,73,92,0.8)",
                pointHighlightStroke: "rgba(54,73,92,1)",
                data                : income_data
            },
                {
                    label               : "<?php echo e(trans('application.expenditure')); ?>",
                    fillColor           : "rgba(244,167,47,0)",
                    strokeColor         : "rgba(244,167,47,1)",
                    pointColor          : "rgba(217,95,6,1)",
                    pointStrokeColor    : "#fff",
                    pointHighlightFill  : "rgba(54,73,92,0.8)",
                    pointHighlightStroke: "rgba(54,73,92,1)",
                    data                : expense_data
                }
            ]
        };
        var pieData = [
            {
                value: '<?php echo $total_payments; ?>',
                color:"#2FB972",
                highlight: "#37D484",
                label: "<?php echo e(trans('application.amount_received')); ?>"
            },
            {
                value: '<?php echo $total_outstanding; ?>',
                color:"#C84135",
                highlight: "#EA5548",
                label: "<?php echo e(trans('application.outstanding_amount')); ?>"
            }
        ];

        $(function(){
            Chart.defaults.global.scaleFontSize = 12;
            var chartDiv = document.getElementById("yearly_overview_inner").getContext("2d");
            lineChart = new Chart(chartDiv).Line(lineChartData, {
                responsive: true
            });
            $('#yearly_overview').append(lineChart.generateLegend());
            var chartDiv = document.getElementById("payment_overview_inner").getContext("2d");
            pieChart = new Chart(chartDiv).Pie(pieData, {
                responsive : true
            });
            $('#payment_overview').append(pieChart.generateLegend());
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invoicer\core\resources\views/home.blade.php ENDPATH**/ ?>