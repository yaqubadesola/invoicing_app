<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            {!! Form::label('name', trans('application.name')) !!}
            {!! Form::text('name', null, ['class' => "form-control input-sm required", 'required']) !!}
        </div>
    </div>
</div>