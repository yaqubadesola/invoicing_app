<?php 
                            return array('install' => true,
                                          'version' => 2,
                                          'install date' => '2021-01-31 06:12:33'
                                        );
                       ?>